import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scr = new Scanner(System.in);

        System.out.print("Введите температуру в градусах Цельсия: ");
        float celsius = scr.nextFloat();

        // Преобразование Цельсия в Фаренгейты
        float fahrenheit = (celsius * 9 / 5) + 32;

        System.out.printf("Температура в Фаренгейтах: %.2f%n", fahrenheit);
    }
}