import javax.swing.*;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        int score = 0;
        boolean exitRequested = false;

        //Создать класс Main, метод main.
        //2) Создать цикл на усмотрение(while, do-while, for).
        //3) На каждой итерации cгенерировать два случайных int-числа,
        // опрашивать пользователя одной из арифметических операций(+,-, *, /),
        // и если он введёт правильное значение, добавлять ему 5 баллов, если неправильное,
        // вычитать 5 баллов.
        //4) Опросник заканчивается, когда пользователь введёт слово "exit".
        //5) По завершению опросника пользователю должно быть выведено количество его баллов за игру.

        //На каждой итерации пользователю должно выводиться сообщение следующего содержания:

        //"Ваш ответ: {ответ_пользователя}. Правильный ответ: {правильный ответ на сумму случайных чисел}.
        // Текущее количество баллов: {количество баллов}"

        //По завершению цикла пользователю должно вывестись сообщение следующего содержания:

        //"Ура! Опросник завершён! Ваш финальный счёт: {финальный счёт}"

        while (!exitRequested) {
            int num1 = random.nextInt(10);
            int num2 = random.nextInt(10);
            int correctAnswer = num1 + num2;
            System.out.println("Summa chisel"  + num1 + " + " + num2 + "=ravna chemu?");
            System.out.println("Your answer (or 'exit' for finishing):");
            String userAnswer = scanner.next();

            if (userAnswer.equalsIgnoreCase("exit")) {
                exitRequested = true;
            } else {
                    int userValue = Integer.parseInt(userAnswer);
                    if (userValue == correctAnswer) {
                        System.out.println("Correct! + 5 points");
                        score += 5;
                    } else {
                        System.out.println("Incorrect! -5 Points");
                        score -= 5;
                    }
                }
            }
            System.out.println("Game is over ! Your results is:" + score);
        }
    }
